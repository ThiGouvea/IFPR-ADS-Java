package Trabalho1511;
import java.util.Scanner;

//1. Crie um programa que mostre os números de 5 a 15.

public class exercicio1 {
    public static void main(String[] args) {
        Scanner Ler = new Scanner(System.in);

        for (int i = 5; i <= 15; i++) {
            System.out.println(i);
        }


    }

}
